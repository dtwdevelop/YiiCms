<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
?>

<div class="site-login well ">
 <?php $form = ActiveForm::begin([
        'id' => 'login-form',
         'method'=>'get',
          'action'=>['/search/search'],
        'options' => ['class' => 'form-horizontal'],
        'fieldConfig' => [
            'template' => "{label}\n<div class=\"col-lg-3\">{input}</div>\n<div class=\"col-lg-8\">{error}</div>",
            'labelOptions' => ['class' => 'col-lg-1 control-label'],
        ],
    ]); ?>

    <?= $form->field($model, 'q') ?>

    <?= $form->field($model, 'type')->dropDownList($model->getType(),['prompt' => 'Select']) ?>
<div class="form-group">
        <div class="col-lg-offset-1 col-lg-11">
            <?= Html::submitButton('Search', ['class' => 'btn btn-primary', 'name' => 'yes']) ?>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
    
    <p><?php if($rezult !== null){
        
    foreach ($rezult as $data){
//      print_r($data);
        if($model->type === '1'){
            if(isset($data->user_id)){
                echo Html::a($data->title, ['/user/account/view','id'=>$data->user_id]);
                 echo Html::tag('br');
            }
            else{
                echo "<p>Not found </p>";
            }
             
        }
        if($model->type === '2'){
            
           if(isset($data->cat_id)){
              echo Html::a($data->title, ['/categories/view','id'=>$data->cat_id]);
              echo Html::tag('br');
            }
              else{
                echo "<p>Not found </p>";
            }
        }
      
      
    
       
    }
  }
   
?></p>
    
</div>
 