<?php
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use kartik\nav\NavX;
use app\modules\media\widzets\last\LastWidget;
/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>

<?php $this->beginBody() ?>
    <div class="wrap">
        <?php
            NavBar::begin([
                'brandLabel' => 'Project X',
                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar-inverse navbar-fixed-top',
                ],
            ]);
            echo Nav::widget([
                'options' => ['class' => 'navbar-nav navbar-right'],
                'items' => [
                    ['label' => 'Admin', 'url' => ['#'],'visible' =>!Yii::$app->user->isGuest,
                        'items'=>[
                         
                          ['label' => 'Accounts', 'url' => ['/user/account/index']],
                          ['label' => 'Categories', 'url' => ['/categories/index']],
                           ['label' => 'Media', 'url' => ['/media/media/index']],
                        ]
                        ],
                    ['label' => 'Home', 'url' => ['/site/index']],
                    ['label' => 'Categories', 'url' => ['/categories/list']],
                    ['label' => 'Blog', 'url' => ['/blog/index']],
                    ['label' => 'Profile', 'url' => ['/site/profile'] , 'visible' =>!Yii::$app->user->isGuest],
                    ['label' => 'Search', 'url' => ['/search/search']],
                    
                    ['label' => 'About', 'url' => ['/site/about']],
                    ['label' => 'Contact', 'url' => ['/site/contact']],
                     ['label' => 'Api', 'url' => ['/api/']],
                    Yii::$app->user->isGuest ?
                        ['label' => 'Account', 'url' => ['#'],
                    'items' => [
             ['label' => 'Login in', 'url' => ['/site/login']],
             '<li class="divider"></li>',
             ['label' => 'Sign up', 'url' => ['/site/register']],
            ['label' => 'Forgot password?','url' =>  ['/site/forgot']],
        ],
              
                            
                            ] :
                        ['label' => 'Logout (' . Yii::$app->user->identity->username . ')',
                            'url' => ['/site/logout'],
                            'linkOptions' => ['data-method' => 'post']],
                ],
            ]);
            NavBar::end();
        ?>


        <div class="container">
            <?= Breadcrumbs::widget([
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ]) ?>
            <div class="row">
                <div class="col-md-3">
                <div class="panel " >
               <div class=" panel1 panel-heading ">Menu</div>
                <div class="panel-body">
                
 <?= NavX::widget([
    'items' => [
        [
            'label' => 'Home',
            'url' => ['site/index'],
            'linkOptions' => [],
            
         
        ],
        [
          'label' => 'Categories', 'url' => ['/categories/index'],'items'=>app\models\Categories::createMenu(0),

                 
        ],
         [
            'label' => 'Blog',
            'url' => ['blog/index'],
            'linkOptions' => [],
            
         
        ],
       
    ],
]);
                ?>
  
               </div>
</div>
    
                
                <div class="panel " >
               <div class="panel2 panel-heading ">Random</div>
                <div class="panel-body">
                <?= LastWidget::widget(['title' => 'Foto']) ?>
                </div>
                </div>
                 </div>
            <div class="col-md-9"> <?= $content ?></div>
           
           
      
    </div>
        </div>
        
    </div>
    <footer class="footer">
        <div class="container">
            
            <p class="pull-left">&copy; Project X <?= date('Y') ?></p>
            <p class="pull-right"><?= Yii::powered() ?></p>
        </div>
    </footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
