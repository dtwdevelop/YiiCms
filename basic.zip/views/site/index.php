<?php
/* @var $this yii\web\View */
use yii\bootstrap\Modal;

$this->title = 'My Yii Application';
?>
<?php echo $test;  ?>
<div class="site-index well">

    <div class="jumbotron">
        <h1>Time do next steps!</h1>
		
    </div>

    <div class="body-content">

        <div class="row">
           
        </div>
        
         <div class="row">
           
        </div>

    </div>
</div>
