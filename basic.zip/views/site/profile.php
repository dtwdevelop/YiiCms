
<h3>Welcome <?=  $name; ?></h3>

