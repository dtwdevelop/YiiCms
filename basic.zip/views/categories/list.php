<?php
use yii\widgets\LinkPager;
?>


<div class="col-md-10">
 <?php foreach ($model as $cat): ?>
    
     <div class="panel ">
               <div class="panel2 panel-heading "><?= $cat->title ?></div>
                <div class="panel-body">
                   <?=  $cat->about ; ?>
                    
                </div>
               <div class="panel-footer"><?= \Yii::$app->formatter->format($cat->created, 'date') ?></div>
     </div>
<?php endforeach; ?>

<?= LinkPager::widget(['pagination' => $pages]) ?>
</div>

