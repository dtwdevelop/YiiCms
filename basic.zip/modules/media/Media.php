<?php

namespace app\modules\media;

class Media extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\media\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
