<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\media\models\Files */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="files-form col-md-6 well">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>
<?= $form->errorSummary($model); ?>
    <?= $form->field($model, 'media_id')->dropDownList($media->getCategoryList(false), ['prompt' => 'Parent Category']); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => 255]) ?>

    <?= $form->field($model, 'file')->fileInput() ?>

   

    <?= $form->field($model, 'topic')->textInput(['maxlength' => 255]) ?>

   

    <?= $form->field($model, 'meta')->textInput(['maxlength' => 255]) ?>

    <?= $form->field($model, 'meta_tags')->textInput(['maxlength' => 255]) ?>

    <?= $form->field($model, 'show')->checkbox() ?>

   

   

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
