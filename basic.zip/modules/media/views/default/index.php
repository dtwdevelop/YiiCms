<div class="media-default-index">
    <h1><?= $this->context->action->uniqueId ?></h1>
    <h3>Gallery </h3>
</div>
