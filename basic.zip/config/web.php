<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
     'defaultRoute' => 'site',
    'language' => 'en-US',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'TY72RPzxCKrwZuBLVd316YnKtj_e7Cx7',
             'parsers' => [
        'application/json' => 'yii\web\JsonParser',
    ],
            
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\modules\user\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
            
        ],
//        'view' => [
//            'class' => 'yii\web\View',
//            'renderers' => [
//                'tpl' => [
//                    'class' => 'yii\smarty\ViewRenderer',
//                    //'cachePath' => '@runtime/Smarty/cache',
//                ],
//                'twig' => [
//                    'class' => 'yii\twig\ViewRenderer',
//                    'cachePath' => '@runtime/Twig/cache',
//                    // Array of twig options:
//                    'options' => [
//                        'auto_reload' => true,
//                    ],
//                    'globals' => ['html' => '\yii\helpers\Html'],
//                    'uses' => ['yii\bootstrap'],
//                ],
//                // ...
//            ],
//        ],
  
        'urlManager' => [
          
            
            'enablePrettyUrl' => true,
            'showScriptName' => false,
//            'enableStrictParsing' => true,
            'suffix' => '.html',
            'rules' => [
            ['class' => 'yii\rest\UrlRule', 'controller' => 'api',
                          
                
                ],
   
         ],
           
        ],
        'authManager' => [
            'class' => 'yii\rbac\PhpManager',
             'defaultRoles' => ['admin','user'], // here define your roles
            //'authFile' => '@console/data/rbac.php' //the default path for rbac.php | OLD CONFIGURATION
            'itemFile' => '@app/data/items.php', //Default path to items.php | NEW CONFIGURATIONS
            'assignmentFile' => '@app/data/assignments.php', //Default path to assignments.php | NEW CONFIGURATIONS
	     'ruleFile' => '@app/data/rules.php', 
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
//            'transport' => [
//            'class' => 'Swift_SmtpTransport',
//            'host' => 'smtp.gmail.com',
//            'username' => 'username@gmail.com',
//            'password' => 'password',
//            'port' => '587',
//            'encryption' => 'tls',
//                        ],
        ],
        'i18n' => [
        'translations' => [
            'app*' => [
                'class' => 'yii\i18n\PhpMessageSource',
                'basePath' => '@app/messages',
//                'sourceLanguage' => 'en-US',
//                'fileMap' => [
//                    'app' => 'app.php',
////                    'app/error' => 'error.php',
//                ],
            ],
        ],
    ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
    ],
     'modules' => [
        'media' => [
            'class' => 'app\modules\media\Media',
        ],
          'user' => [
            'class' => 'app\modules\user\User',
        ],
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = 'yii\gii\Module';
}

return $config;
