<?php

return [
    'adminEmail' => 'site@localhost',
    'site' =>'http://sitedev.lv',
    'bigFoto'=>'uploads/big/',
    'smallFoto'=>'uploads/small/',
    'index'=>'data/index',
];
