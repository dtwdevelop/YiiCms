<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ApiController
 *
 * @author hide
 */
namespace app\controllers;

use yii\rest\ActiveController;
use app\models\User;
use yii\web\Response;
use yii\filters\auth\HttpBasicAuth;


class ApiController extends ActiveController {
   public $modelClass = 'app\models\api\User';
//      public function actionIndex()
//{
//    return User::findAll();
//    
//}

   public function init()
{
    parent::init();
    \Yii::$app->user->enableSession = false;
}

public function behaviors()
{
    $behaviors = parent::behaviors();
     //$behaviors['authenticator'] = ['class' => HttpBasicAuth::className(),];
    $behaviors['contentNegotiator']['formats']['text/html'] = Response::FORMAT_JSON;
    return $behaviors;
}
//http://sitedev.lv/api/view.html
   public function actionView($id)
{
    return User::findOne($id);
}

 

}
