<?php
namespace app\controllers;
use app\models\Categories;
use app\models\Page;
use app\modules\user\models\Profile;
use app\models\SearchForm;
use ZendSearch\Lucene\Lucene;
use ZendSearch\Lucene\Document;
use ZendSearch\Lucene\Document\Field;
use ZendSearch\Lucene\Search\QueryParser;
use Yii;
class SearchController extends \yii\web\Controller

{
    public function actionSearch()
    {
        $req = Yii::$app->request;
        $search = new SearchForm;
       
        if($search->load(Yii::$app->request->get())){
            $this->Create();
            $find  = $search->q;
            
           
           $query  = QueryParser::parse($find,'UTF-8');
           $index = Lucene::open(Yii::$app->params['index']);
           $hits= $index->find($query);
          
          
           return $this->render('search',['model'=>$search ,'rezult'=>$hits]);
        }
        else{
        return $this->render('search',['model'=>$search,'rezult'=>null]);
        }
    }
    
    public function   Create(){
       
        
        $model = Profile::find()->all();
        $categories = Categories::find()->all();
        $index = Lucene::create(Yii::$app->params['index']);
        if($model !== null){
        foreach($model as $val){
        $document = new Document();
        $document->addField(Field::unIndexed('user_id', $val->profile_id));
        $document->addField(Field::text('title', $val->name));
        $document->addField(Field::text('email', $val->email));
        $document->addField(Field::unStored('date', $val->created));
        
        $index->addDocument($document);
        }
        }
        if($categories !== null) {
        foreach($categories as $cat){
        $document = new Document();
        $document->addField(Field::unIndexed('cat_id', $cat->category_id));
        $document->addField(Field::text('title', $cat->title));
        
        $document->addField(Field::unStored('date', $cat->created));
        
        $index->addDocument($document);
        }
        }
        
        $index->optimize();
        $index->commit();
        $total = $index->numDocs();
       
    }

}
