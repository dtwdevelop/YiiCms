<?php
namespace app\models;
use yii\db\ActiveRecord;
/**
 * Description of Article
 *
 * @author hide
 */
class News extends ActiveRecord  {
    
    
}
